---
name: writing-content
version: 3.0
description: Thought leadership framework for writing B2B blog content that changes how readers think
author: Chatty Content Team
argument-hint: "posts/[slug].md"
audience:
  - Shopify merchants
  - Ecommerce operators
  - CX and growth teams
---
Write thought leadership content that argues a point, not just covers a topic.
Strictly follow the mindset, writing flow, and rules below:

---

## Core Mindset: Thought Leadership (MUST READ FIRST)

### The fundamental difference

| Content Writer (avoid) | Thought Leader (target) |
|------------------------|-------------------------|
| "I cover this topic" | "I argue this point" |
| Research → Organize → Write | Observe → Form thesis → Support with evidence |
| Sections cover different aspects | Sections build on each other |
| Define terms, explain basics | Skip obvious, go straight to insight |
| Neutral, balanced | Has opinions, makes calls |
| Reader learns information | Reader changes how they think |
| Giải thích topic | Argue một điểm về topic đó |

### The dual role: Thought Leader + Expert Advisor

Thought leadership alone is not enough. You must also be an **Expert Advisor** who guides readers to action.

| Thought Leader | Expert Advisor |
|----------------|----------------|
| "I argue this point" | "I guide you through this" |
| Changes how reader thinks | Makes reader act |
| Has opinions | Has directives |
| Reader believes differently | Reader knows exactly what to do |

**Both are required:**
- Without thought leadership → generic content, no differentiation
- Without expert advisor → reader agrees but doesn't act

**The formula:** Educate (free value) + Guide (actionable steps) + Solve (product as enabler)

### The core principle

**Outline determines WHAT you cover (to match search intent). Thesis determines WHAT YOU ARGUE while covering it (to create value).**

Both are required:
- Without outline compliance → miss intent → lose ranking
- Without thesis → generic content → no differentiation

### Five thought leadership principles

**1. Start with thesis, not topic**

Thesis = 1 câu có thể disagree, thay đổi cách reader nghĩ nếu họ believe.

- ❌ "This article is about customer value"
- ✅ "Cost reduction creates more value than benefit addition"

**2. Earn the right to advise**

Before saying "you should do X", demonstrate:
- You understand the problem deeply
- You know where people commonly fail
- You know why conventional approaches fall short

**3. Skip the obvious**

- Don't define terms everyone knows
- Don't list things people can Google
- Don't explain basics that your audience already understands

Skip obvious stuff WITHIN sections. Don't skip whole sections required by outline.

**4. Connect, don't list**

- A → B → C (each section builds on previous)
- Not A, B, C (disconnected list)

Each section must answer: "Why does reader need this BEFORE reading the next section?"

**5. Have opinions**

Make calls:
- "This approach is overrated"
- "Most advice here is wrong"
- "Skip this, focus on that"
- "This matters more than people think"

No fence-sitting ("it depends", "there are pros and cons" without resolution).

---

## Writing flow

### Input
- Complete outline from SKILL-outline (includes: heading structure, direction, key points, data needs, word count per heading, keyword list, Chatty relevance)

### Step 0: Live Deep Research & Paradigm Sync (Crucial)
- Before creating any outline or writing, you MUST conduct live research on the main keyword to understand the cutting-edge 2026/Agentic AI consensus.
- **Where to search:** Prioritize Hacker News, Reddit (r/artificial, r/SaaS, r/ecommerce), and high-tier tech blogs (a16z, OpenAI, Anthropic).
- **Search Query Strategy:** Do NOT search generic terms. Search for "[Keyword] + Agentic AI", "[Keyword] + LLM autonomous workflow", or "[Keyword] + zero-click execution".
- **Output:** Write a hidden HTML comment synthesizing the 3 most advanced technical insights you found. Example: `<!-- RESEARCH SYNTHESIS: 1. [Insight from HN/Reddit]. 2. [Insight from tech blog]. 3. [Counter-intuitive finding]. -->`

### Step 1: Read and understand the outline
- Identify the main keyword, target audience, and search intent
- Note the required sections (H2s, H3s) — these are non-negotiable for SEO
- Check Chatty relevance: which sections allow Chatty mentions, or no mention at all
- **Read `data/brand/2026-paradigm-shifts.md`** to understand the Agentic framing for this topic
- **Read "Thought Leadership Inputs" section carefully:**
  - Competitor weakness: What gaps can you fill?
  - Audience context: What can you skip? What do they struggle with?
  - Suggested angle: Starting point for your thesis (you will finalize in Step 1.5)

### Step 1.5: Form your thesis (CRITICAL)

**Before writing anything, you MUST form a thesis.**

A thesis is NOT:
- A topic ("This article is about customer value")
- A summary ("We'll cover types, measurement, and improvement")

A thesis IS:
- An argument that could be disagreed with
- A point of view that changes how reader thinks
- A thread that runs through every section

**How to form thesis:**

1. Review outline's "Thought Leadership Inputs":
   - What competitor weaknesses can you address?
   - What does your audience already know (skip) vs struggle with (focus)?
   - Does the suggested angle resonate, or do you see a better direction?
2. Ask: "What do most people get wrong about this topic?"
3. Ask: "What would an expert say that a beginner wouldn't?"
4. Synthesize into 1 sentence that captures your argument

**Note:** You may use, modify, or completely change the outline's suggested angle. The outline provides inputs — you make the final call.

**Thesis must be:**
- Compatible with outline (enhance the required sections, not contradict them)
- Specific enough to argue
- Valuable enough that reader thinks differently after believing it

**Output:** Write a hidden HTML comment with your thesis:
```
<!-- THESIS: [Your 1-sentence argument that runs through the entire article] -->
```

**Example:**
```
<!-- THESIS: Cost reduction creates more customer value than benefit addition — but most companies only pull the benefit lever because costs are invisible. -->
```

### Step 1.6: Map thesis to sections

For each H2 required by outline, write how it supports your thesis:

```
<!-- SECTION MAP:
- H2 What is customer value → Setup: introduce the equation, plant seed that "cost" is misunderstood
- H2 Why it matters → Reinforce: show that value-driven companies win on cost reduction
- H2 Types of value → Develop: group types into benefit vs cost, argue cost types are underleveraged
- H2 How to measure → Apply: focus on cost metrics (effort) first, then CLV
- H2 How to improve → Conclude: prioritize cost reduction tactics, show higher ROI
-->
```

This ensures every section CONNECTS and BUILDS toward your argument, not just covers different aspects.

### Step 2: Write title + meta description + slug

#### Title guidelines
A good title must meet all these criteria:

| Requirement | Details |
|-------------|---------|
| **< 60 chars** | SEO-friendly, không bị cắt trên SERP |
| **Sát content** | Pull từ opening hook, counterintuitive insight, hoặc FAQ trong bài |
| **Match intent** | How-to → signal practical guide; Explainer → signal clarity; Comparison → signal decision help |
| **Có pull** | Thêm outcome, tension, hoặc specificity để hấp dẫn |
| **Conversational** | Tránh formula quen thuộc, viết như người thật nói |
| **Sentence case** | "A no-nonsense guide to..." không phải "A No-Nonsense Guide To..." |

**Process:**
1. Đọc bài → xác định intent (how-to? explainer? comparison?)
2. Tìm hook từ content (opening pain point, counterintuitive tip, FAQ)
3. Chọn format phù hợp intent
4. Thêm pull (outcome, tension, specificity)
5. Check: < 60 chars + sentence case

**Pull techniques:**
- **+ Outcome:** "...and actually use it", "...that drives results"
- **+ Specificity:** "7 types, 7 steps", "step by step"
- **+ Tension:** "...without overcomplicating it", "...the right way"
- **+ Confidence:** "...that works", "...you can act on"

**Good examples:**
- "A no-nonsense guide to customer segmentation" (practical guide)
- "How to segment customers (and actually use it)" (how-to with outcome)
- "Customer segmentation you can actually act on" (actionable promise)

**Bad examples:**
- "Customer segmentation: types, benefits, and how to do it" (generic, no pull)
- "The ultimate guide to customer segmentation" (overused formula)
- "7 Customer Segmentation Strategies That Actually Work" (title case, formulaic)

#### Meta description + slug
- Write meta description and slug as specified in the outline
- Optimize heading with keywords naturally if not already included

### Step 3: Write key takeaways box
- After finishing the sapo (introduction), insert a "Key takeaways" section before the first H2
- Summarize 3-5 main takeaways from the entire article in bullet points
- Each takeaway: 1 sentence, clear and actionable
- This section is written AFTER completing all other sections (step 4-5), then placed here in the final article
- Purpose: give readers the core value upfront so they know what to expect

### Step 4: Write each section using "Thesis Connection"

**Before writing each H2/H3, you MUST:**
1. Check your SECTION MAP from Step 1.6
2. Write a hidden HTML comment declaring how this section supports your thesis
3. Then write the actual prose

**Comment format:**
```
<!-- SECTION PURPOSE: [How this section advances the thesis] + [What reader should believe after reading] -->
```

**Example:**
```
## Types of customer value

<!-- SECTION PURPOSE: Group 8 types into benefit vs cost categories to show that cost-reduction types are underleveraged. Reader should believe that convenience/service value (cost types) have higher ROI than functional/social value (benefit types). -->

Eight types of customer value exist in the literature. But they're not created equal...
```

**Section writing rules:**
- Cover all key points required by outline (for SEO intent match)
- BUT frame every point through your thesis (for differentiation)
- Stay within the fixed word count for each heading
- Keywords will appear naturally when you write about the topic — don't force placement
- Only mention Chatty in sections marked in the outline
- Insert internal links naturally within the content

**Per-section execution:**
1. Cover what outline requires (intent)
2. Frame it through thesis (insight)
3. Add what expert would add (depth)
4. Skip obvious explanations within section (efficiency)

### Step 4.5: Thought Leadership Self-Correction

After drafting each section, evaluate against TWO checks:

#### Check 1: Thought Leadership Quality

| Question | If NO, fix it |
|----------|---------------|
| Am I ARGUING or just EXPLAINING? | Rewrite to take a position |
| Does this connect to my thesis? | Add explicit connection |
| Would an expert nod or roll eyes? | Cut obvious parts, add depth |
| Did I skip obvious definitions? | Remove unnecessary explanations |
| Do I have an opinion here? | Add a call/judgment |

**Beginner signals to catch and fix:**

| Signal | Beginner writes | Expert writes |
|--------|-----------------|---------------|
| Throat-clearing | "In today's competitive landscape..." | Start with content immediately |
| Over-explaining | "CLV, which stands for Customer Lifetime Value, is a metric that..." | "CLV = AOV × Frequency × Lifespan. Simple formula. Knowing what to do with it isn't." |
| Hedging | "This might work depending on..." | "This works for X. For Y, it backfires." |
| Generic transitions | "Additionally...", "Furthermore..." | "That explains X. But not Y." |
| Announcing | "In this section, we will explore..." | Just say it directly |
| Equal weighting | Every point gets same treatment | "Of these eight, three actually matter." |
| Passive voice | "It is recommended that..." | "Do this." |
| Empty summary | "As we have seen, this is complex..." | Specific takeaway |

#### Check 2: Agentic Framing (for AI-related content)

1. **Did I sound like 2023 content?** (human workflows, deflection, "AI assists agents")
2. **Did I demonstrate AI taking autonomous action?** (AI completes tasks, not just responds)

**Quick signals of 2023 thinking:**
- "AI helps agents..." → "AI handles autonomously..."
- "Route to human..." → "AI resolves, human adds empathy layer..."
- "Deflect tickets..." → "AI completes customer goal..."
- "Chatbot answers..." → "AI takes action..."

**Do NOT proceed to next section until current section passes both checks.**

### Step 5: Write closing section
- Heading must NOT be generic ("Conclusion", "Bottom line", "Final thoughts"). Write a descriptive heading that summarizes the article's core message and includes a keyword naturally (e.g., "Unlock smarter and more autonomous service with agentic AI")
- Summarize the key ideas from all sections above — do not introduce new information
- Distill a clear, actionable insight the reader takes away from the article
- Include CTA as specified in the outline (matched to funnel stage)
- Follow the word count from the outline

### Step 6: Write FAQ
- Answer each question listed in the outline
- Each answer: 2-4 sentences, direct and practical
- Format for FAQ schema markup

### Step 7: Self-check

**Thought leadership check (do this FIRST):**
1. Read only the headings — can you follow the argument?
2. Is the thesis clear from the introduction?
3. Does each section BUILD on the previous one?
4. Would an expert in this field nod along, or roll their eyes?
5. What does reader think DIFFERENTLY after reading?

**Outline compliance check:**
- All key points covered?
- Word count per heading correct?

**Writing quality check:**
- Voice/tone, BLUF, paragraph length, sourcing, transitions
- No beginner signals (throat-clearing, over-explaining, hedging)?

**GEO optimization check:**
- First 200 words directly answer main query?
- Each H2 has 1+ citable sentence (stat + source)?
- Sections are self-contained (no pronoun starts)?
- FAQ answers are 30-50 words, answer-first?
- 3+ data points per 500 words?

**Run through FINAL CHECKLIST below before publishing.**

---

## Core philosophy (non-negotiable)

1. **Argument over coverage**
   - Every article must argue a point, not just cover a topic.
   - Reader should think differently after reading, not just know more.
   - If you don't have a thesis, you're not ready to write.

2. **Information first, not advertising**
   - Content must be valuable.
   - Reader value is the primary success metric.

3. **Trust over persuasion**
   - Accuracy, sourcing, and transparency matter more than conversion.
   - Never exaggerate or oversell.

4. **Experience over theory**
   - Write like an expert explaining to a peer, not a researcher summarizing for students.
   - Skip basics your audience already knows.
   - Have opinions. Make calls.

5. **Clarity over cleverness**
   - Simple language.
   - One idea at a time.
   - No buzzwords or filler.

### The "First-Principles" Agentic Mindset Algorithm
For EVERY topic you write about, run it through this mental algorithm before drafting:
1. **The 2023 Baseline:** How was this done with traditional human teams? (Identify this only to critique it).
2. **The Autonomous Shift:** If there are ZERO humans involved, how does an LLM agent accomplish this exact goal using APIs, tool-calling, and reasoning?
3. **The Data Layer:** What real-time data does the AI need to ingest to make a decision instantly?
4. **The Execution:** Use active execution verbs (*ingest, intercept, autonomously trigger, cross-reference*) instead of passive verbs (*reply, assist, suggest*).

---

## GEO Optimization (Generative Engine Optimization)

AI search engines (ChatGPT, Perplexity, Google AI Overviews) now drive significant traffic. GEO ensures our content gets cited in AI-generated answers.

**Why this matters:** AI engines cite only 2-7 sources per response. Content optimized for AI extraction gets cited; content that isn't gets ignored — regardless of traditional SEO ranking.

**GEO vs SEO:** GEO builds ON SEO, doesn't replace it. 78% of AI Overview citations come from top 10 Google results. Strong SEO foundation = better GEO performance.

### GEO principles

#### 1. First 200 words = direct answer

AI engines extract opening passages for citations. The intro must answer the main query within 200 words.

**Structure:**
- **Words 1-60:** Direct answer to main query (no buildup)
- **Words 61-120:** Key supporting stat or evidence
- **Words 121-200:** Context and scope of article

❌ Bad (buildup first):
> "In today's competitive ecommerce landscape, customer experience has become increasingly important. Many merchants struggle with..." [answer buried at word 300]

✅ Good (answer first):
> "The average ecommerce store loses 67% of potential sales to cart abandonment. The fix isn't more discounts — it's faster response to purchase hesitation. Here's how leading Shopify merchants cut abandonment by 23% using real-time intervention."

**Self-check:** Can an AI extract your first 60 words as a standalone answer? If not, rewrite.

#### 2. Self-contained sections (extractable answer blocks)

Each H2/H3 must work as a standalone, quotable unit. AI may extract one section without context from other sections.

**Rules:**
- Avoid starting sections with pronouns ("It", "This", "They")
- Repeat the subject noun for clarity
- Each section should make sense if read in isolation
- Target: 120-180 words per section (optimal for AI extraction)

❌ Bad (requires prior context):
> "### Why it matters
> This approach reduces costs significantly. It also improves satisfaction scores."

✅ Good (self-contained):
> "### Why proactive support reduces costs
> Proactive support intercepts issues before they become tickets. A preemptive shipping delay notification costs nothing to send. The angry support ticket it prevents costs $15-25 in agent time. Merchants using proactive alerts see 30% fewer inbound contacts."

#### 3. Citable sentences (quotable data points)

AI prefers content with specific, verifiable claims. Every H2 needs at least one "citable sentence" — a standalone claim with specific data that AI can quote directly.

**Formula:** [Specific claim] + [Specific number] + [Source]

❌ Not citable:
> "AI improves customer service significantly."

✅ Citable:
> "AI-powered support reduces response time by 60% and resolution time by 40%, according to [Salesforce](url)."

**Target density:** 3+ citable data points per 500 words (research shows 4.1x more AI citations)

**Citable sentence types:**
- **Stat:** "Cart abandonment costs ecommerce $18 billion annually (Baymard)."
- **Benchmark:** "Top-performing stores maintain sub-60-second response times."
- **Comparison:** "Proactive chat converts 3x better than reactive popups."
- **Threshold:** "Resolution rates above 70% indicate healthy automation."

#### 4. Answer-Evidence-Context structure

Align with BLUF but add evidence layer for AI extraction.

**Pattern for each section:**

```
[Direct answer to section question — 1-2 sentences]

[Evidence: stat, example, or proof — with source]

[Context: why this matters, how to apply]
```

**Example:**

> ## How long should you wait before following up?
>
> Follow up within 5 minutes for hot leads, 24 hours for warm inquiries. Response time directly impacts conversion — leads contacted within 5 minutes are 9x more likely to convert ([InsideSales](url)).
>
> The 5-minute window matters because buyer intent peaks immediately after inquiry. After 30 minutes, intent drops 50%. After 24 hours, most leads have moved on or contacted competitors.

#### 5. Semantic clarity for AI parsing

AI extracts passages out of context. Unclear references = unusable content.

**Rules:**
- Start sections with the subject noun, not pronouns
- Repeat key terms rather than using synonyms (AI matches exact terms)
- Use parallel structure in lists
- Avoid ambiguous modifiers

❌ Ambiguous:
> "They often struggle with this. It can be improved by implementing better systems."

✅ Clear:
> "Support teams often struggle with response time. Response time improves when teams implement automated routing and pre-written templates."

#### 6. FAQ optimization for AI

FAQ sections are high-value for AI extraction. Perplexity and ChatGPT frequently cite FAQ content.

**FAQ format rules:**
- Question: ~15 words / 80 characters max
- Answer: 30-50 words, direct and complete
- First sentence = direct answer
- Include one specific data point when relevant
- Use exact phrasing users would search

❌ Weak FAQ:
> **Q: What is customer retention?**
> A: Customer retention refers to the strategies and activities companies use to prevent customers from leaving.

✅ Strong FAQ:
> **Q: What's a good customer retention rate for ecommerce?**
> A: 20-30% for most ecommerce stores; 40%+ for subscription businesses. Retention above industry average indicates strong product-market fit and customer satisfaction. Focus on repeat purchase rate as your primary metric.

### GEO content structure targets

| Element | Target |
|---------|--------|
| Total word count | 2,500-4,000 words |
| Section length | 120-180 words |
| First answer block | 40-60 words |
| Data density | 3+ facts per 500 words |
| External citations | 5-8 per 1,000 words |

### GEO technical requirements

#### Schema markup (publishing checklist)
- FAQPage schema for FAQ section
- Article schema with author, datePublished, dateModified
- HowTo schema for step-by-step content

**Impact:** +30% AI citation rate for FAQPage schema; +36% visibility for Article schema.

#### Freshness signals
- Add "Last updated: [YYYY-MM-DD]" to article metadata
- Review/update high-value articles every 30 days
- Perplexity citation rates drop significantly for content > 30 days old

---

## Writing rules

### Voice & tone

Write in a voice that is:
- **Expert, not researcher** – you’re sharing what you know, not summarizing what you found
- **Confident, not hedging** – make calls, take positions, state opinions directly
- **Simple and clear** – avoid jargon; when you must use technical terms, don’t over-explain
- **Friendly and warm** – speak like a knowledgeable colleague, not a corporate brochure
- **Advisory, not salesy** – offer guidance; don’t push a product or sound like marketing

**Expert voice signals:**
- Knows what to skip (doesn’t explain obvious things)
- Has opinions (says "this is overrated" or "focus on X, not Y")
- Makes connections (sees patterns others miss)
- Acknowledges complexity honestly (without hiding behind "it depends")

### Directive tone

Write like a consultant giving instructions, not a researcher presenting options.

| Hedging (avoid) | Directive (use) |
|-----------------|-----------------|
| "You might want to consider..." | "Do this." |
| "It’s recommended that..." | "Implement X." |
| "There are several approaches..." | "Three actions matter:" |
| "This could potentially help..." | "This works. Here’s how." |

**Action verbs:** Implement, Audit, Build, Deploy, Measure, Cut, Focus, Skip, Prioritize

**Why:** Readers come for guidance, not options. Tell them what to do.

### Conversational, not academic

Viết như giải thích cho đồng nghiệp, không phải viết paper.

❌ Academic:
> "Metrics incentivize suboptimal behaviors that prioritize velocity over quality."

✅ Conversational:
> "Tickets closed per hour incentivizes rushing. Average handle time punishes thoroughness."

❌ Academic:
> "Tiered SLAs outperform flat response targets in multi-priority environments."

✅ Conversational:
> "A security breach and a ‘how do I export my data?’ question shouldn’t share the same SLA."

### Style rules
- Sentence case for title and all headings – capitalize only the first word and proper nouns
- Active voice – "you can do" instead of "it can be done" keeps prose lively
- Short paragraphs (1–3 sentences) – limits cognitive load and improves scanning
- One idea per paragraph
- Prefer sentences under ~22 words
- Use contractions naturally (you're, it's, don't)
- Limit negative sentences
- Prioritize sentences with complete subjects and predicates. Avoid sentences that begin with only a predicate (verb).
- No buzzwords. No filler. No hype. No em dash (—).

### 2026 Vocabulary Rules (Do's and Don'ts)
- **DON'T USE:** "Chatbot", "Automated replies", "Support tickets", "Customer satisfaction surveys", "Deflection rate".
- **USE INSTEAD:** "Agentic AI / AI Sales Agent", "Autonomous resolution", "Contextual handoff", "Predictive sentiment", "Real-time action", "Zero-party data".

### BLUF rule (Bottom Line Up Front) ⚠️ HIGHEST PRIORITY WRITING RULE
- **If a heading asks a question, the first sentence MUST answer it directly.** "Why X costs more" → open with "because Y." "How X works" → open with the method. Never circle around the answer.
- Say the answer first. Then explain it.
- Every paragraph should lead with its main point, not build up to it.
- Readers should understand the takeaway before reading the supporting details.
- Stats and context support the answer — they don't replace it. Never open a section with data before stating the point the data proves.

### Structure rules
- H2 headings must be descriptive and complete — never use vague titles like "How it works" or "Why it matters" without specifying the subject (e.g., "How AI-powered segmentation works" not "How it works")
- No H2 section can have only 1 H3 subsection. If an H2 has just one H3, either merge the H3 content into the H2 or split into multiple H3s.

### Funnel structure (reader journey)

Each section serves a purpose in the reader's decision journey:

| Section type | Purpose | Reader state after |
|--------------|---------|-------------------|
| Problem/Definition | Understand the issue | "I get what this is" |
| Impact/Stakes | Feel the urgency | "This matters to me" |
| Solution/How-to | Know what to do | "I know the steps" |
| Proof/Case study | Believe it works | "Others succeeded" |
| FAQ | Remove doubts | "My questions answered" |

**Self-check:** Does each section move reader closer to action, or just add information?

### Lead-in rule (transitions before format changes)
Always add a transition sentence when switching from paragraph to H3s or bullet points. Without this, readers feel "dropped" into lists abruptly.

**Before H3 subsections:**
- Every H2 section with multiple H3s must have a lead-in sentence before the first H3.
- Include a count when possible ("Here are five strategies:", "Two actions matter most:").
- Example: "Several proven strategies move CSAT scores upward. Here are five that consistently work:"

**Before bullet lists:**
- Every bullet list must have a leading sentence introducing it.
- Example: "Industry benchmarks provide context. Here's how they compare:"

**Bad (no transition):**
```
Several proven strategies move CSAT scores upward.

### Respond faster to customer inquiries
```

**Good (with transition):**
```
Several proven strategies move CSAT scores upward. Here are five that consistently work:

### Respond faster to customer inquiries
```

### Formatting rules

#### Paragraph rules
- Each paragraph must be 1-3 sentences. Break longer paragraphs.
- Single-sentence paragraphs are OK for emphasis or key points.
- Mix explanatory sentences ("This happens because...") with action-oriented sentences ("Start by...").
- One idea per paragraph. New concept = new paragraph.

#### Bullet point rules
- Bullets supplement prose. They do not replace it.
- Every bullet list must have a leading paragraph before it. Optionally add a closing paragraph after.
- Do not write sections that are only bullet points with no prose.

#### When to use bullets
- Lists of steps, signals, metrics, or options
- Questions that frame a problem
- Comparisons or timelines
- Items that benefit from scanning

#### When NOT to use bullets
- Explanations that need context and flow
- Arguments that build on each other
- Narratives or case study descriptions
- Any content where prose would be more natural

#### Bullet formatting
- Use **bold labels** when presenting principles, signals, or steps.
- Do not use rigid labels like "**The problem.**" / "**The fix.**" across every subsection. Keep prose natural.

### Transition rules
- Every paragraph must connect logically to the next. No abrupt jumps.
- Paragraphs within a subsection need transitions. Use short bridging sentences like "These three layers reinforce each other." or "That said, automation needs a clear boundary."
- No unsupported claims.
- Bullet points only when they improve clarity.
- Use transitions naturally: "However…", "In practice…", "As a result…", "That means…", "Over time…"

### Connective tissue

Không cắt hết câu kết nối. Cần đủ để flow tự nhiên, không choppy.

**Cụm nên dùng:**
- "The problem is that..."
- "Here's how to implement each one"
- "This is an X problem, not a Y problem"
- "The fix is..."
- "That's backwards"

❌ Telegraphic (quá cắt):
> "Prevention works. Handling costs money. Math favors prevention."

✅ Natural flow:
> "The math is simple. Handling a ticket costs agent time every single time. Preventing a ticket costs nothing after initial setup."

### No choppy negation-then-correction

Không dùng pattern "X isn't Y. It's Z." — hai câu ngắn chẻ đôi ý tạo cảm giác choppy, robotic. Merge thành một câu flowing.

**Techniques:** dùng "rather than", "not X but Y", em dash, "beyond X", "the real X is Y", hoặc đảo câu.

❌ Choppy:
> "The problem isn't data scarcity. It's the gap between having data and using it."
> "This isn't about replacing humans. It's about deploying them where they add value."
> "The goal isn't comprehensive data. It's a quick pulse."

✅ Flowing:
> "The real gap sits between having data and actually using it."
> "The point is deploying humans where they add the most value, not replacing them."
> "The goal is a quick pulse on whether your support team is delivering — not comprehensive data."

### Questions as transitions

Câu hỏi dẫn dắt và giữ engagement. Dùng để mở section hoặc bridge giữa ideas.

**Examples:**
- "How do you know if an article works?"
- "Why do tickets fail to resolve on first contact?"
- "What does this mean in practice?"
- "So what should you do instead?"

### Cost of inaction (responsible urgency)

Show readers what happens if they don't act. Reality check, not hype.

**How to create urgency without hype:**
- Frame the competitive gap: "While you wait, competitors capture your customers"
- Quantify the cost: "Every month without X costs you Y"
- Show the trajectory: "This gap widens over time"

✅ Good:
> "Waiting feels safe. But it means playing catch-up later."
> "Merchants who delay lose 23% more customers to competitors with faster response."

❌ Hype (avoid):
> "Act NOW or miss out forever!"
> "This is a game-changer you can't ignore!"

**Why:** B2B readers are skeptical of hype. Show them the math, not the emotions.

### Compliance checklist
- Use "you" and "your" to talk directly to reader
- Be honest about limits and tradeoffs
- Start with problem, end with solution
- Don't use hype words ("game-changing")
- Don't pad word count with filler
- Don't mix live chat and chatbots carelessly


## Content rules
### Quality rules
- Content must be authoritative and insightful, not generic.
- Content must use specific examples over vague claims (e.g., "A billing dispute often works better over email, where both sides have a written record" instead of "Different issues need different channels").

#### Real examples, not hypotheticals

Đừng dùng "Cửa hàng A", "Brand X". Dùng ví dụ cụ thể với context thực.

❌ Generic:
> "A store that doesn't respond quickly will lose sales."

✅ Specific:
> "A Shopify store selling fitness gear with 10,000 monthly visitors loses roughly $5,000/week in revenue if midnight messages go unanswered."

**Elements of a real example:**
- Industry/niche cụ thể (fitness gear, not "products")
- Numbers cụ thể ($5,000/week, not "significant revenue")
- Situation cụ thể (midnight messages, not "delayed responses")

### Sourcing rules
- Every statistic must have a real source with a direct link.
- Content must not include fabricated or estimated numbers.
- If no reliable data exists, remove the claim entirely.

#### Claim → Evidence → So What

Mỗi claim cần proof và implication. Không chỉ state — prove và explain why it matters.

❌ Claim only:
> "Prevention has higher ROI than handling."

✅ Claim + Evidence + So What:
> "Handling a ticket costs agent time every single time. Preventing a ticket costs nothing after initial setup. If you handle 1,000 tickets per month and prevent 30%, that's $72,000 saved per year."

**Structure:** [Claim] → [Evidence/proof] → [So what / implication for reader]

#### When to use statistics
- Statistics are supporting evidence, not the backbone of every paragraph.
- Add a statistic only if it genuinely strengthens the argument and provides concrete proof.
- Not every subsection needs a data point. If the logic is clear on its own, do not force a stat in.
- Aim for 1–2 stats per subsection maximum. If a subsection has 3+ stats, it is overloaded.
- Use specific numbers, never ranges or estimates: "19% of workweek" not "15-20% of workweek"
- Use exact outcomes when available: "$75K in revenue" not "significant revenue"

#### GEO data density
- Target: 3+ specific data points per 500 words for AI citation optimization
- Every H2 should have at least 1 quotable stat with source (citable sentence)
- Research shows content with 3+ data points per 500 words gets 4.1x more AI citations
- Balance: enough data for AI citability, not so much it overwhelms the argument

#### How to source
- Every statistic must include a real source with a direct link.
- Use the source name as the link text: [Salesforce](url), [Gartner](url). Never write [source](url).
- Never write "studies show" or "research suggests" without citation. Use exact source names.
- No fabricated or estimated numbers. Remove the claim if no reliable data exists.
- Format: "Workers spend 19% of their workweek searching for information, according to [McKinsey](url)."

#### One URL, one link rule
- Each external URL must only be linked ONCE in the entire article.
- **First citation:** Include the full hyperlink with source name as anchor text.
- **Subsequent citations:** Mention source name in parentheses without link.
- **Why:** Multiple links to the same URL can be seen as over-optimization, hurting SEO.
- **Example:**
  - First: "Live chat delivers [87% satisfaction](https://example.com/stats) versus phone."
  - Later: "The average CSAT is around 78% (AmplifAI)."

#### Evidence sources (priority order)

1. **Chatty original research** - 50,000+ merchants, 50M+ conversations (prioritize for eCommerce chat/AI topics)
2. **Gartner** - Technology and business research
3. **McKinsey & Company** - Business strategy and operations
4. **Forrester** - Customer experience and technology
5. **Baymard Institute** - Ecommerce-specific research
6. **Public SaaS reports** - Company earnings reports, case studies, benchmarks
7. **Official documentation** - Product guides, platform documentation

**Rule:** If no reliable statistic is available, remove the claim entirely rather than inventing numbers.

#### Chatty research handling
- Use general attribution: "Chatty research shows..." or "According to Chatty's merchant data..."
- Include scope: "...across 4 industries and 15,600+ conversations"
- Do not present as industry-wide truth — frame as Chatty's findings
- Mix with external sources for balanced credibility

### Insight rules
- Content must not repeat generic advice that readers already know
- Your thesis IS your insight — it should run through every section
- Outline specifies WHAT to cover; you determine HOW to argue it
- You MUST form original insights that support your thesis — this is thought leadership, not content assembly
- Each section should leave reader thinking differently, not just knowing more

### AI optimization rules
- Content must be structured for AI systems to parse and cite
- Use specific numbers: "$75K in revenue" not "significant revenue"
- Use exact metrics: "99.9% resolution rate" not "high resolution"
- Include company/product names when relevant
- Keep content timeless: evergreen topics stay relevant longer


## AI and automation framing (The 2026 Agentic Paradigm)
- **From Chatbots to Agents:** Frame Chatty as an "Agentic AI" that takes autonomous actions (e.g., executing refunds, offering dynamic discounts based on real-time sentiment).
- **The Empathy Handoff:** AI handles 90% of end-to-end resolutions autonomously (Zero-Click Resolution). Humans are reserved ONLY for high-empathy, complex emotional edge cases.
- **Predictive over Reactive:** 2026 AI predicts customer needs based on behavioral cues before the customer types a message.
- **Conversational Commerce:** Support and Sales are merged. Every support interaction is a continuous sales loop.

## Blog goals

**Primary goal (required for ALL articles):**
- Change how reader thinks about the topic (not just inform them)

**Secondary goals (meet at least 3):**
- Be direct and specific
- Be authoritative and evidence-backed
- Be experience-based (expert perspective, not researcher summary)
- Be actionable
- Provide fresh or counter-intuitive insight
- Take clear positions (not fence-sitting)

## Product rules & reference materials

| Purpose | File/Folder |
|---------|-------------|
| **2026 Agentic framing (MUST READ)** | `data/brand/2026-paradigm-shifts.md` |
| Chatty product info, features, USP | `data/competitors/chatty.md`, `data/competitors/chatty-feature-analysis.md` |
| Real merchant results, proof points | `data/case-studies/` |
| **Chatty original research** | `data/research/` |
| **External media mentions** | `data/media-mentions.md` |
| Competitor overview & gap analysis | `data/competitors/COMPETITORS.md`, `data/competitors/GAP.md` |
| Competitor details & feature analysis | `data/competitors/{name}.md`, `data/competitors/{name}-feature-analysis.md` |
| Brand voice, tone guidelines | `data/brand/brand-guidelines.md` |

---

## Chatty research & thought leadership

### Why use Chatty research
Chatty has original research based on 50,000+ merchants and 50M+ conversations. Using this data:
- Establishes Chatty as an authority in eCommerce customer service
- Provides unique data points competitors cannot replicate
- Builds E-E-A-T signals (Experience, Expertise, Authority, Trust)

### Research files available

| Research | Key Data | Use When |
|----------|----------|----------|
| `01-chat-to-sale-conversion-benchmark.md` | 10.5% chat-to-sale conversion, $9-15 revenue per chat | Discussing chat ROI, conversion, revenue attribution |
| `02-ai-resolution-vs-product-complexity.md` | 80-99% AI resolution by product type | Discussing AI chatbot performance, automation rates |
| `03-shopify-merchant-review-analysis.md` | 96% 5-star ratings, 1,761 reviews analyzed | Discussing merchant satisfaction, AI adoption |

### How to cite Chatty research

**Format:** Use general attribution, not specific report names (reports not yet public).

**Good examples:**
- "Chatty research across 4 industries and 15,600+ conversations shows..."
- "According to Chatty's analysis of 1,761 merchant reviews..."
- "Chatty's merchant data shows technical products achieve 98-99% AI resolution..."

**Bad examples:**
- "Chatty AI Resolution Benchmark, 2026" (too specific)
- "Our research shows..." (sounds promotional)
- "Studies show..." (no attribution)

### When to use Chatty research

**Use when:**
- Article topic directly relates to a research finding (chat conversion, AI resolution, etc.)
- External data is unavailable or weak for the specific claim
- Adding unique insight that competitors cannot provide
- Outline marks section for Chatty data

**Do NOT use when:**
- Forcing data into unrelated topics
- Outline does not specify Chatty data for the section
- External authoritative source (Gartner, McKinsey) covers the same point better

### Integration rules

1. **Read research files before writing** — understand what data is available
2. **Match research to outline** — use Chatty data only in sections where it fits naturally
3. **Balance sources** — mix Chatty research with external sources (Gartner, McKinsey, etc.)
4. **Don't overload** — 1-2 Chatty data points per article is usually sufficient
5. **Context matters** — always explain what the data means for the reader

### Media mentions

Check `data/media-mentions.md` for external videos/blogs featuring Chatty. Use these for:
- Social proof ("Featured in [publication]...")
- External validation of Chatty's approach
- Building backlink opportunities in future content

### Chatty mention rules
- Follow Chatty placement from the outline — only mention in sections the outline marks
- If outline says "no Chatty mention", do not add any

#### Problem → Solution → Product

**Don't** just "mention" Chatty. **Create the problem first**, then introduce Chatty as the natural solution.

**Flow:**
1. **Create tension:** Show a pain point that's hard to solve manually
2. **Heighten stakes:** What happens if unsolved?
3. **Introduce solution:** Chatty solves this specific problem
4. **Show proof:** Metric or merchant result

**Example:**

❌ Weak (just mentioning):
> "Chatty helps you respond faster to customers."

✅ Strong (Problem → Solution):
> "Most merchants don't know a customer is frustrated until they've already left. By then, it's too late."
>
> "Chatty's AI agent detects frustration signals in real-time and autonomously offers a recovery discount — before the customer abandons."

#### Contextual CTAs

CTA phải specific theo context bài viết, không generic.

❌ Generic:
> "Start your free trial"

✅ Contextual:
> "Tạo kịch bản chốt đơn tự động cho store của bạn (14 ngày miễn phí)"
> "Xem cách Chatty detect frustrated customers trong real-time"

**CTA formula:**
`[Action verb] + [Specific outcome from this article] + [Low friction offer]`

**Placement:** After demonstrating value, when reader thinks "I want that" — not just at the end.

#### How to mention (when allowed)
- Focus on merchant outcomes, not features
- Use phrases like "Some merchants using Chatty have seen..."
- Keep promotional language minimal
- Chatty must be positioned as "one proven solution among options", not the only or best solution

---

## FINAL CHECKLIST

This checklist is part of Step 7 (Self-check). Before publishing, verify:

**THOUGHT LEADERSHIP (MOST IMPORTANT):**
- [ ] Thesis is clear and stated early in the article
- [ ] Every section connects to and supports the thesis
- [ ] Sections BUILD on each other (A → B → C), not just list aspects (A, B, C)
- [ ] Reading just the headings reveals the argument flow
- [ ] Opinions are stated — not fence-sitting
- [ ] Obvious definitions and basics are skipped
- [ ] Reader will think DIFFERENTLY after reading, not just know more
- [ ] No beginner signals: throat-clearing, over-explaining, hedging, announcing

**OUTLINE COMPLIANCE:**
- [ ] All key points from outline covered
- [ ] Word count per heading matches outline
- [ ] Chatty mentions only in outline-marked sections (or none if outline says so)
- [ ] Internal links inserted following SEO insert agent rules

**WRITING QUALITY:**
- [ ] Voice/tone matches rules (simple, friendly, confident, advisory)
- [ ] BLUF applied — every paragraph leads with its main point
- [ ] Short paragraphs (1-3 sentences)
- [ ] Active voice used
- [ ] Directive tone — "Do X" not "Consider X"
- [ ] Transitions show LOGIC, not just signal next point
- [ ] Connective tissue — flow tự nhiên, không choppy
- [ ] No grammar errors

**CONTENT QUALITY:**
- [ ] Evidence-based claims only — all stats sourced
- [ ] Specific examples over vague claims
- [ ] Each section has insight, not generic advice
- [ ] Scannable formatting (bullets supplement prose, bold labels)
- [ ] Chatty research used where relevant (check `data/research/`)
- [ ] Chatty data cited with general attribution (not specific report names)

**AGENTIC FRAMING (for AI-related content):**
- [ ] AI framed as autonomous agent taking action (not assistant to humans)
- [ ] Metrics focus on resolution/autonomy rate (not response time/ticket count)
- [ ] No "chatbot deflection" or "route to agent" language

**EXPERT ADVISOR CHECK:**
- [ ] Mỗi section moves reader closer to action?
- [ ] Cost of inaction shown (không hype)?
- [ ] Real examples với specific context? (không "Cửa hàng A")
- [ ] Claim → Evidence → So What structure?

**PRODUCT-LED CHECK:**
- [ ] Problem tạo trước, Chatty giải sau?
- [ ] Contextual CTA (không generic)?
- [ ] CTA đặt đúng "wow" moment?

---

## EXAMPLES

### Thought Leadership Examples

**Example: Same section, two approaches**

Topic: "Functional value" (one of 8 types of customer value)

❌ **Content Writer approach:**
> ### Functional value
>
> Does the product do what it claims? In ecommerce: does the item match the listing, arrive intact, and work as described?
>
> Functional value is table stakes. You won't win customers by delivering products that work. But you'll lose them permanently if you fail here. The key is setting accurate expectations—detailed specs, realistic photos, honest reviews—so customers arrive with expectations you can actually meet.

✅ **Thought Leader approach:**
> ### Functional value is where you lose, not win
>
> No customer thinks "wow, the product actually works!" But they absolutely notice when it doesn't. This asymmetry matters: functional value has no upside, only downside risk.
>
> The implication: don't over-invest here. Meet expectations, don't exceed them. The ROI on "slightly better product photos" is near zero. The ROI on reducing checkout friction is 10x higher.

**What changed:**
- Skipped obvious definition (everyone knows products should work)
- Added opinion ("don't over-invest here")
- Connected to thesis (cost reduction > benefit addition)
- Made a specific call (compare ROI of two approaches)

---

### Title Examples

**Good (sentence case, with pull):**
- "How predictive sentiment analysis saves Shopify sales in real-time"
- "Customer value: why the old formula no longer works"

**Bad (generic, no argument):**
- "Customer value: definition, types, and how to improve it"
- "The ultimate guide to customer value"

---

### Opening Examples

❌ **Beginner (throat-clearing):**
> "In today's competitive ecommerce landscape, understanding customer value has become more important than ever. Businesses that want to succeed need to understand what their customers truly value and how to deliver it effectively."

✅ **Expert (straight to insight):**
> "Two companies sell similar products at similar prices. One has 70% repeat customers, the other has 20%. The difference isn't product quality—it's how much effort customers spend buying and getting help."

---

### Chatty Mention Examples

**Good (Agentic focus):**
> "Instead of routing angry customers to a queue, Chatty's AI agent calculates a real-time frustration index and autonomously generates a 10% apology discount to save the sale instantly."

**Bad (2023 thinking):**
> "Chatty helps your support team respond faster to customer questions."

---

### Chatty Research Citation Examples

**Good:**
> "Chatty research across 50,000+ merchants shows that autonomous AI resolutions for shipping inquiries convert 23% of frustrated customers into repeat buyers within the same session."

**Bad:**
> "According to the Chatty AI Resolution Benchmark 2026, resolution rates range from 80% to 99%." (Don't use specific report names)
