---
name: humanize
description: Anti-AI-detection writing reference. Use to review and humanize AI-generated content.
---

## AI detection triggers to eliminate

### Corporate buzzwords (replace immediately)
| AI Phrase | Human Alternative |
|-----------|------------------|
| delve | dig into, explore, look at |
| landscape | space, world, scene, market |
| leverage | use, take advantage of |
| robust | strong, solid, powerful, reliable |
| streamline | simplify, make easier, clean up |
| ensure | make sure, guarantee |
| utilize | use |
| facilitate | make easier, help with |
| implement | set up, put in place, start using |
| comprehensive | complete, full, thorough, detailed |

### AI transitions (replace with casual connectors)
| AI Transition | Human Alternative |
|---------------|------------------|
| moreover | Plus, Also, And, On top of that |
| furthermore | Plus, Also, What's more |
| however | But, Though, That said, Still |
| nevertheless | Still, Even so, But |
| therefore | So, That's why, Which means |
| thus | So, That's why, Meaning |
| in addition | Also, Plus, And |
| in conclusion | (remove or rewrite) |

### Formal phrases (simplify)
| Formal | Natural |
|--------|---------|
| in order to | to |
| it is essential to | you need to, make sure you |
| it is important to note | note that, keep in mind |
| allows you to | lets you, you can |
| enables you to | lets you, you can |
| provides the ability to | lets you, you can |

## Humanization techniques

1. **Vary rhythm** -- mix short punchy sentences with longer flowing ones
2. **Add imperfection** -- start with "And" or "But", use casual connectors, parentheticals
3. **Inject personality** -- specific examples, mild opinions, rhetorical questions
4. **Natural flow** -- brief tangents, emphasis with bold/italics, questions mid-thought

## Red flags to check after writing

- [ ] Any sentence starting the same way 3+ times?
- [ ] More than 2 sentences in a row with similar length?
- [ ] Any corporate buzzwords remaining?
- [ ] Using "However" or "Moreover"?
- [ ] Missing contractions (it is -> it's)?
- [ ] No emphasis (bold/italics)?
- [ ] Too polite/safe?
