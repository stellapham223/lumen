# Content Creation Workflow

## Overview

```
Step 1: Research       ->  generate-outline [topic] + competitor URLs
Step 2: Review         ->  approve / edit / regenerate
Step 3: Write          ->  writing-content articles/[slug].md
Step 4: Internal links ->  seo-internal-linking articles/[slug].md
Step 5: Images         ->  creating-images articles/[slug].md
Step 6: Publish        ->  publish articles/[slug].md
Step 7: Final          ->  Review checklist
```

---

## Step 1: Generate outline

**Input:** keyword + competitor URLs

**Process:**
1. Read Chatty product overview (`data/brand/chatty-product-overview.md`)
2. Analyze competitor headings, structure, gaps
3. Determine search intent and content type
4. Create outline with word count per section
5. Extract keyword list (secondary, semantic, NLP)

**Output:** Outline file in `articles/[keyword-slug].md`

**Skill:** `.claude/skills/generate-outline/SKILL.md`

---

## Step 2: Review outline (requires approval)

**Options:**
- `approve` -- continue to writing
- `edit: [feedback]` -- adjust outline
- `regenerate` -- create new outline

---

## Step 3: Write article

**Input:** Outline file from step 1

**Process:**
1. Read outline and keyword list
2. **Read Chatty research files** (`data/research/`) — identify relevant data points for the topic
3. Write title, meta description, slug, intro
4. Write each section per word count
5. Apply writing rules (BLUF, active voice, short paragraphs)
6. Add sources and statistics (including Chatty research where relevant)
7. Write FAQ
8. Write key takeaways (placed after intro)
9. Self-check against outline and writing rules

**Skill:** `.claude/skills/writing-content/SKILL.md`
**Reference:** `.claude/skills/writing-content/HUMANIZE.md` (anti-AI-detection)
**Research:** `data/research/` (Chatty original data for thought leadership)

---

## Step 4: Add internal links

**Input:** Written article + WordPress MCP

**Data source:** WordPress MCP (`wp_search_posts`, `wp_verify_url`)

**Rules:**
1. Anchor text MUST match keyword exactly
2. Each keyword linked only once (first occurrence)
3. Links must fit naturally in context
4. Target: 3-6 internal links per article

**Skill:** `.claude/skills/seo/SKILL.md`
**Scripts:** `seo_suggest_agent.py`, `seo_insert_agent.py`

---

## Step 5: Create images

**Input:** Written article

**Process:**
1. Read article, analyze structure
2. Insert `<!-- IMAGE: type -->` markers
3. Show summary, wait for approval
4. Generate images (HTML/CSS -> WebP)
5. Replace markers with image references

**Skill:** `.claude/skills/creating-images/SKILL.md`

---

## Step 6: Publish

**Input:** Final article

**Process:**
1. Run `python .claude/skills/publish/scripts/wp_autoposter.py --file article.md`
2. Article uploaded as WordPress draft
3. Review in WordPress admin

**Skill:** `.claude/skills/publish/SKILL.md`

---

## Step 7: Final review checklist

**Content:**
- [ ] Title has main keyword, under 60 chars
- [ ] Meta description has keyword, under 160 chars
- [ ] Authoritative and insightful content
- [ ] Evidence-based claims with sourced links
- [ ] All statistics have linked sources

**Writing quality:**
- [ ] Short paragraphs (2-4 sentences)
- [ ] Active voice, BLUF applied
- [ ] Transitions connect paragraphs logically
- [ ] No AI buzzwords (check HUMANIZE.md)
- [ ] No grammar errors

**Internal links:**
- [ ] 3-6 internal links added
- [ ] Anchor text = keyword exactly
- [ ] Links fit naturally in context

**Images:**
- [ ] Alt text describes content
- [ ] File size < 100KB each
- [ ] IMG numbers sequential (1, 2, 3...)

**GEO (AI search optimization):**
- [ ] First 60 words directly answer main query
- [ ] Each H2 has 1+ citable sentence (stat + source)
- [ ] Sections are self-contained (120-180 words, no pronoun starts)
- [ ] FAQ answers are 30-50 words, answer-first format
- [ ] 3+ data points per 500 words
- [ ] Last updated date in metadata

---

## File structure

```
.claude/skills/
├── generate-outline/
│   ├── SKILL.md                    <- Outline creation framework
│   └── scripts/
│       ├── content_research_agent.py
│       ├── outline_agent.py
│       └── content_generator.py
│
├── writing-content/
│   ├── SKILL.md                    <- Writing rules and flow
│   ├── WORKFLOW.md                 <- This file
│   ├── HUMANIZE.md                 <- Anti-AI-detection reference
│   ├── articles/                   <- Article files
│   └── scripts/
│       ├── chatty_style_guide.py
│       └── humanize_agent.py
│
├── seo/
│   ├── SKILL.md                    <- Internal linking rules
│   └── scripts/
│       ├── seo_knowledge.py
│       ├── seo_suggest_agent.py
│       ├── seo_insert_agent.py
│       └── seo_audit_agent.py
│
├── creating-images/
│   ├── SKILL.md                    <- Image creation guide
│   ├── PROMPTS.md                  <- Layout prompts
│   ├── scripts/
│   │   ├── html_to_image.py
│   │   ├── generate_image.py
│   │   └── blog_image.py
│   ├── data/templates/
│   │   └── background.png
│   └── images/                     <- Generated images
│
└── publish/
    ├── SKILL.md                    <- WordPress publishing
    └── scripts/
        ├── wp_autoposter.py
        ├── blog_automation.py
        └── content_automation_master.py

data/
├── brand/
│   ├── chatty-product-overview.md
│   └── brand-guidelines.md
├── case-studies/
├── research/                        <- Chatty original research (thought leadership)
│   ├── 01-chat-to-sale-conversion-benchmark.md
│   ├── 02-ai-resolution-vs-product-complexity.md
│   └── 03-shopify-merchant-review-analysis.md
├── media-mentions.md               <- External videos/blogs featuring Chatty
├── chatty-product-overview/
└── competitors/
```
